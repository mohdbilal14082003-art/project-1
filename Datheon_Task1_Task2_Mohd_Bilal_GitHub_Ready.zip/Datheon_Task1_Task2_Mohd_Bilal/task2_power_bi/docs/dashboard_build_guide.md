# Task 2 — Interactive Power BI Executive Sales & Profit Dashboard

## Objective
Build an executive dashboard that monitors sales, profitability, order volume, discounting and product/region performance using the supplied retail dataset.

## Data source
Import `datasets/superstore_retail_clean.csv` (or `datasets/superstore_retail_reference.csv`) into Power BI Desktop. The project data is **synthetic portfolio data**, not a company’s confidential or official Superstore extract.

## Data model
1. Rename the imported query to `Orders`.
2. Set `Order Date` and `Ship Date` to Date; `Sales` and `Profit` to Decimal Number; `Quantity` to Whole Number; `Discount` to Decimal Number.
3. Create a calendar table with DAX:

```DAX
Date =
ADDCOLUMNS(
    CALENDAR(MIN(Orders[Order Date]), MAX(Orders[Order Date])),
    "Year", YEAR([Date]),
    "Month Number", MONTH([Date]),
    "Month", FORMAT([Date], "MMM"),
    "Year-Month", FORMAT([Date], "YYYY-MM")
)
```

4. Mark `Date` as the date table using `Date[Date]`.
5. Create a one-to-many, single-direction relationship: `Date[Date]` (one) → `Orders[Order Date]` (many).
6. Sort `Date[Month]` by `Date[Month Number]`; sort `Date[Year-Month]` by a numeric year-month key if using it as a text axis.

## DAX measures
Copy measures from `dax/measures.dax` after creating the `Date` table. Format Sales, Profit and Average Order Value as currency; margins, discount and YoY as percentages; order and quantity measures as whole numbers.

## Recommended one-page executive layout
- **Header:** “Executive Sales & Profit Overview” with reporting period.
- **KPI cards:** Total Sales, Total Profit, Profit Margin %, Total Orders, Average Order Value.
- **Trend:** Line chart with Date[Year-Month] on axis and Total Sales / Total Profit as values.
- **Regional view:** Bar chart, Region by Total Sales; add Total Profit to tooltip.
- **Category view:** Clustered column chart, Category by Total Sales and Total Profit.
- **Product performance:** Bar chart, Product Name by Total Sales; Top N = 10.
- **Discount analysis:** Scatter chart, Discount on X, Profit on Y, Sales as size; Product/Category as details or legend.
- **Slicers:** Year, Region, Segment, Category, Ship Mode.

## Interactions and formatting
- Enable cross-filtering between charts; verify Edit interactions.
- Use a consistent restrained palette, clear titles, data labels where helpful and display units in thousands/millions.
- Use a report page tooltip for product details if time permits.
- Add a reset-filters button using a bookmark.
- Keep slicers aligned at the top or left; avoid overcrowding.

## Validation checklist
- Compare card totals with `task1_eda/outputs/` summaries or a pivot table.
- Check that selecting a Region changes all relevant visuals.
- Check that the Date slicer filters the trend and KPI cards.
- Confirm Profit Margin = Total Profit / Total Sales (not average row margin).
- Confirm the date relationship is active and no duplicate date values exist in Date.
- Save as `Datheon_Executive_Sales_Profit_Dashboard.pbix`.

## Expected deliverable
A `.pbix` Power BI Desktop file plus screenshots of the final page. This repository provides the cleaned dataset, DAX, data-model instructions, layout specification and validation checklist. The `.pbix` file must be created and saved in Power BI Desktop; it is not fabricated here.
