# Datheon Data Analytics & Power BI Internship — Tasks 1 & 2
**Submitted by:** Mohd Bilal  
**Institution:** Aligarh Muslim University  
**Domain:** Data Analytics  
**Programme:** Datheon Data Analytics & Power BI Internship (Batch 01)

## Included projects
- **Task 1:** Exploratory Data Analysis (EDA) on Superstore Retail Sales — data profiling, cleaning, descriptive statistics, sales/profit analysis, visualizations and exports.
- **Task 2:** Interactive Power BI Executive Sales & Profit Dashboard — model instructions, DAX measures, layout, slicers, interaction and QA checklist.

## Important dataset note
The supplied CSVs are **synthetic demonstration data** created to make this project reproducible. They are not represented as Datheon's official starter dataset or the official Sample Superstore dataset. If Datheon provides a required starter dataset, replace the raw CSV and rerun the EDA; then refresh the Power BI model and recheck all results.

## Run Task 1
```bash
pip install -r requirements.txt
python task1_eda/src/run_eda.py
```
Outputs are saved in `task1_eda/outputs/`; the cleaned dataset is saved to `datasets/superstore_retail_clean.csv`.

## Build Task 2
1. Open Power BI Desktop.
2. Get Data → Text/CSV → select `datasets/superstore_retail_clean.csv`.
3. Follow `task2_power_bi/docs/dashboard_build_guide.md`.
4. Add measures from `task2_power_bi/dax/measures.dax`.
5. Save the finished report as `Datheon_Executive_Sales_Profit_Dashboard.pbix`.

## Repository structure
```
Datheon_Task1_Task2_Mohd_Bilal/
├── datasets/
├── task1_eda/
│   ├── src/
│   └── outputs/
├── task2_power_bi/
│   ├── dax/
│   └── docs/
├── reports/
├── requirements.txt
└── README.md
```
