"""
Datheon Task 1: Exploratory Data Analysis on Superstore Retail Sales
Run from repository root: python task1_eda/src/run_eda.py
The supplied dataset is synthetic and intended for portfolio demonstration.
"""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "datasets" / "superstore_retail_raw.csv"
OUT = ROOT / "task1_eda" / "outputs"
OUT.mkdir(parents=True, exist_ok=True)

df = pd.read_csv(DATA, parse_dates=["Order Date", "Ship Date"])
print("Raw shape:", df.shape)
print("\nMissing values:\n", df.isna().sum())
print("\nDuplicate rows:", df.duplicated().sum())

df = df.drop_duplicates().copy()
df["Postal Code"] = df["Postal Code"].fillna(0).astype(int)
df["Ship Mode"] = df["Ship Mode"].fillna(df["Ship Mode"].mode()[0])
df["Customer Name"] = df["Customer Name"].fillna("Unknown Customer")
df["Order Year"] = df["Order Date"].dt.year
df["Order Month"] = df["Order Date"].dt.to_period("M").astype(str)
df["Profit Margin"] = np.where(df["Sales"] != 0, df["Profit"] / df["Sales"], 0)
df["Shipping Days"] = (df["Ship Date"] - df["Order Date"]).dt.days

print("\nClean shape:", df.shape)
print("\nDescriptive statistics:\n", df[["Sales","Quantity","Discount","Profit"]].describe())
print("\nSales by region:\n", df.groupby("Region")["Sales"].sum().sort_values(ascending=False))
print("\nProfit by category:\n", df.groupby("Category")["Profit"].sum().sort_values(ascending=False))

monthly = df.groupby(df["Order Date"].dt.to_period("M")).agg(
    Sales=("Sales","sum"), Profit=("Profit","sum")
).reset_index()
monthly["Order Month"] = monthly["Order Date"].astype(str)
monthly.to_csv(OUT / "monthly_trend.csv", index=False)
df.to_csv(ROOT / "datasets" / "superstore_retail_clean.csv", index=False)

plt.figure(figsize=(10,5))
plt.plot(monthly["Order Month"], monthly["Sales"], marker="o")
plt.title("Monthly Sales Trend"); plt.xlabel("Month"); plt.ylabel("Sales")
plt.xticks(rotation=60); plt.tight_layout()
plt.savefig(OUT / "monthly_sales_trend.png", dpi=160); plt.close()

region = df.groupby("Region", as_index=False).agg(Sales=("Sales","sum"), Profit=("Profit","sum"))
region.to_csv(OUT / "region_summary.csv", index=False)
plt.figure(figsize=(8,5)); plt.bar(region["Region"], region["Sales"])
plt.title("Sales by Region"); plt.ylabel("Sales"); plt.tight_layout()
plt.savefig(OUT / "sales_by_region.png", dpi=160); plt.close()

category = df.groupby("Category", as_index=False).agg(Sales=("Sales","sum"), Profit=("Profit","sum"))
category.to_csv(OUT / "category_summary.csv", index=False)
plt.figure(figsize=(8,5)); plt.bar(category["Category"], category["Profit"])
plt.title("Profit by Category"); plt.ylabel("Profit"); plt.tight_layout()
plt.savefig(OUT / "profit_by_category.png", dpi=160); plt.close()

plt.figure(figsize=(8,5)); plt.scatter(df["Discount"], df["Profit"], alpha=.35)
plt.title("Discount vs Profit"); plt.xlabel("Discount"); plt.ylabel("Profit")
plt.tight_layout(); plt.savefig(OUT / "discount_profit.png", dpi=160); plt.close()
print("\nEDA completed. See task1_eda/outputs and datasets/superstore_retail_clean.csv")
